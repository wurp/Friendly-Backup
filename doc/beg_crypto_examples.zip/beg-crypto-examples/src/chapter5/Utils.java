package chapter5;

/**
 * Chapter 5 Utils
 */
public class Utils extends chapter4.Utils
{

}
